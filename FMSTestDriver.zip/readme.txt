Usage: java -jar FMSTestingObf.jar <hostname> <port>
